**OneFlowWater**

Do water board with style

This mod allows you to do water board in one flow, it has a timer, and ping you when you should click the levers
